<h1>TCC de RPG</h1>

>status do projeto: Desenvolvimento

Essa versão não tem banco de dados 
Para rodar esse projeto:

```
precisa do XAMPP, versão v3.3.0
```

finalizar o Front


:>
